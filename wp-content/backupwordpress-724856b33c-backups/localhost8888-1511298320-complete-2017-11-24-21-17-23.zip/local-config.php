<?php
define('DB_NAME', 'Apolda Kennels');
define('DB_USER', 'root');
define('DB_PASSWORD', 'root');
define('DB_HOST', 'localhost' );
$table_prefix  = 'wp_';
